package hospital;
import java.util.Date;

public class BMI {
    
   
    private double weightKilograms , weightPounds  ,heightMetres , heightInches, BMI;
    private Date dateCreated;
   
public BMI (){
    weightKilograms = 0;
    heightMetres = 0;    
    weightPounds = 0;
    heightInches = 0; 
}

public void setDate(Date DATE){
        DATE = dateCreated;
    }

public double getWeightKilogrames(){
       return weightKilograms;
}
public void setweightKilogrames(double WeightKilogrames){
    this.weightKilograms =  WeightKilogrames;
    }
public double getWeightPounds(){
    return weightPounds;
}
public void setweight(double weightPounds){
    this.weightPounds = weightPounds;
}
public double getheightInches(){
    return heightInches;
}
public void setheightInches(double heightInches){
   this.heightInches = heightInches;
}
public double getheightMetres(){
    return heightMetres;
}
public void setheightMetres(double heightMetres){
    this.heightMetres = heightMetres;
}
public double getBMI(){
    return BMI;
}
public void setBMI(double BMI){
    this.BMI = BMI;
}

public double CalculateBMI(double weightKilograms,double heightMetres){
    double BMI = weightKilograms/Math.pow(heightMetres,2);
    return BMI;
}
public double CalculateBMI2(double weightPounds, double heightInches){
    double BMI = (weightPounds/Math.pow(heightInches,2)) * 703;
    return BMI;
}
public Date getDate(){
       return new Date();       
    }
}





