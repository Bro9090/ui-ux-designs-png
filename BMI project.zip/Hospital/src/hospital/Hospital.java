package hospital;
import java.awt.Button;
import java.awt.Insets;
import java.awt.Label;
import static java.awt.SystemColor.window;
import java.awt.TextField;
import java.util.Scanner;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class Hospital {  

    public static void main(String[] args){        
      
   
    Scanner reader = new Scanner (System.in);
    
/*
        String name ;
         System.out.println("Input name of Patient");
             name = reader.next();
               
         int idNo;
        System.out.println("Input ID number of Patient");
            idNo = reader.nextInt();
 */            
        String Gender;
        System.out.println("Input Gender (MALE / FEMALE)");
            Gender = reader.next();
        
        int age;
        System.out.println("Input Age of Patient");
            age = reader.nextInt();
 /*                
        String Address;
        System.out.println("Input Address");
            Address =reader.next();
*/
        
        //BMI (CalculateBMI) USES INPUT AS Kilogrames and Metres    
        //BMI2(CalculateBMI2) USES INPUT AS Pounds and Inches 
        //The output will be inform of KG/M^2
                  

        System.out.println("Enter weight ");
             double x= reader.nextDouble();
        System.out.println("Enter height ");
            double y = reader.nextDouble();
        
        BMI Patient_1 = new BMI ();
        System.out.println("  BMI  is \n "+ Patient_1.CalculateBMI(x, y)+ "  Kg/m^2");               
       
            if (Patient_1.CalculateBMI(x, y)<16 )
        System.out.println("FEEDBACK \n Severe Thinness");
            
            else if (Patient_1.CalculateBMI(x, y)>=16 && Patient_1.CalculateBMI(x, y)<17 )
        System.out.println( "FEEDBACK \n Moderate thiness");
            else if (Patient_1.CalculateBMI(x, y)>=17 && Patient_1.CalculateBMI(x, y)<18.5 )
        System.out.println("FEEDBACK \n Mild thiness");
            else if ( Patient_1.CalculateBMI(x, y)>=18.5 && Patient_1.CalculateBMI(x, y)<25)
        System.out.println("FEEDBACK \n Normal");
            else if (Patient_1.CalculateBMI(x, y)>=25 && Patient_1.CalculateBMI(x, y)<30)
        System.out.println("FEEDBACK \n Over weight");
            else if (Patient_1.CalculateBMI(x, y)>=30 && Patient_1.CalculateBMI(x, y)<35)
        System.out.println("FEEDBACK \n Obese class 1");
            else if (Patient_1.CalculateBMI(x, y)>=35 && Patient_1.CalculateBMI(x, y)<40)
        System.out.println("FEEDBACK \n Obese class 2");            
            
            else  System.out.println("Obese class 3"); 
        
        //Blood Pressure Measurement
        double Systolic ,Diastolic;                    
        System.out.println("Kindly Input (Upper limit)Systolic(mmHg) and (Lower limit)Diastolic (mmHg)of Blood Pressure(B/P) systematically");
            Systolic = reader.nextInt();
            Diastolic = reader.nextInt();
       
            if (Systolic<130 && Diastolic <80)
        System.out.println("B/P is normal");
            
            else if (Systolic>=120 && Systolic<=139 || Diastolic>=80 && Diastolic<=89 )
        System.out.println("Prehypertension");
            else if (Systolic>=140 && Systolic<=159 || Diastolic>=90 && Diastolic<=99 )
        System.out.println("Hypertension STAGE 1");
            else if (Systolic>=160 && Diastolic>=100 )
        System.out.println("Hypertension STAGE 2");
            else if (Systolic>180 && Diastolic>120)
        System.out.println("Hypertensive Crisis");
            
            else 
        System.out.println("Seek further medical attention ASAP!!");
            
        System.out.println(Patient_1.getDate());
         } 
   
    Label labelBMI = new Label("BMI");
    GridPane gridPane = new GridPane(); 
    

   
    
    Label labelAge = new Label("Age");
    TextField nameAge = new TextField();     
        
    
    Label Gender = new Label("Gender");
    TextField nameGender = new TextField();    
    
    Label Height = new Label("Height");
    TextField nameHeight = new TextField();  
    
    
    Label Weight = new Label("Weight");
    TextField nameWeight = new TextField();     
    
    Button calculate  =new Button("CALCULATE");
    
    TextField nameFeedback = new TextField();  
    
    
    Label labelBloodPressure = new Label("BLOOD PRESSURE");        
   
    
    Label Systolic = new Label("Systolic(mmHg)");
    TextField nameSystolic = new TextField();     
    
    
    Label Diastolic = new Label("Diastolic(mmHg)");
    TextField nameDiastolic = new TextField();    
    
    Button Check  =new Button("CHECK");
    
    Label Feedback = new Label("B/P Feedback");
    TextField nameFeedBack = new TextField();
   
      
}