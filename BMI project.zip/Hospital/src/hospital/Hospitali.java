package hospital;

public class Hospitali {
    
}
